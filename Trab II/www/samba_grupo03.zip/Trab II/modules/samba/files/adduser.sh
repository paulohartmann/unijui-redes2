sudo useradd -m -g users -p bemsegura pauloh
(echo "bemsegura"; echo "bemsegura") | smbpasswd -s -a pauloh
